
package model;

import javax.persistence.*;

/**
 *
 * @author jeremie
 */


@Entity
public class ClientTable {
    @Id
    @Column(name = "reg_no")
    private String regNo;
    private String firstname;
    private String lastname;
    private String phone_number;
    private String client_category;
    private String email;
    private String photopath;
    byte[] photo2;
    public ClientTable() {
    }

    public ClientTable(String regNo, String firstname, String lastname, String phone_number, String client_category, String email, String photopath, byte[] photo2) {
        this.regNo = regNo;
        this.firstname = firstname;
        this.lastname = lastname;
        this.phone_number = phone_number;
        this.client_category = client_category;
        this.email = email;
        this.photopath = photopath;
        this.photo2 = photo2;
    }

    public ClientTable(String regNo) {
        this.regNo = regNo;
    }

    public String getRegNo() {
        return regNo;
    }

    public void setRegNo(String regNo) {
        this.regNo = regNo;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public String getPhone_number() {
        return phone_number;
    }

    public void setPhone_number(String phone_number) {
        this.phone_number = phone_number;
    }

    public String getClient_category() {
        return client_category;
    }

    public void setClient_category(String client_category) {
        this.client_category = client_category;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhoto() {
        return photopath;
    }

    public void setPhoto(String photopath) {
        this.photopath = photopath;
    }

    public byte[] getPhoto2() {
        return photo2;
    }

    public void setPhoto2(byte[] photo2) {
        this.photo2 = photo2;
    }
    
    
}
