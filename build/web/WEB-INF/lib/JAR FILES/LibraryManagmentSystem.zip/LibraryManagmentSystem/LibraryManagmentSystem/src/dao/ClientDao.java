
package dao;

import java.util.List;
import model.ClientTable;
import org.hibernate.*;

/**
 *
 * @author jeremie
 */
public class ClientDao {
    
    public String saveClient(ClientTable client){
        // create session
        Session ss = HibernateUtil.getSessionFactory().openSession();
        // create transaction
        Transaction tr = ss.beginTransaction();
        ss.save(client);
        tr.commit();
        ss.close();
        return "data saved successful";
    }
    
     public String updateClient(ClientTable client){
        // create session
        Session ss = HibernateUtil.getSessionFactory().openSession();
        // create transaction
        Transaction tr = ss.beginTransaction();
        ss.update(client);
        tr.commit();
        ss.close();
        return "data saved successful";
    }
     
      public String deleteClient(ClientTable client){
        // create session
        Session ss = HibernateUtil.getSessionFactory().openSession();
        // create transaction
        Transaction tr = ss.beginTransaction();
        ss.delete(client);
        tr.commit();
        ss.close();
        return "data saved successful";
    }
    
       public List<ClientTable> getAllClient(ClientTable client){
        // create session
        Session ss = HibernateUtil.getSessionFactory().openSession();
        List<ClientTable> clientList = ss.createQuery("from client ClientTable client").list();
        ss.close();
        return clientList;
    }
       
    public ClientTable findClientByRegNo(ClientTable info){
        // create session
        Session ss = HibernateUtil.getSessionFactory().openSession();
        ClientTable client = (ClientTable)ss.get(ClientTable.class, info.getRegNo());
        ss.close();
        return client;
    }
    
    
}
